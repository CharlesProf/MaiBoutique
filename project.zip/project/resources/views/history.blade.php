@extends('layout.navbar')

@section('title', 'History')

@section('content')
    <h1>History</h1>
@endsection
