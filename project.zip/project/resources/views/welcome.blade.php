@extends('layout.navbar')

@section('title', 'Welcome to MaiBoutique')

@section('content')
    <h1>Welcome to MaiBoutique</h1>
    <h3>
        <a class="w-100 form-control-sm btn-primary" style="text-align: center" href="/signup" type="button">Sign Up Now</a>
    </h3>

@endsection
