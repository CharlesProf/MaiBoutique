@extends('layout.navbar')

@section('title', 'Search')

@section('content')
    <h1>Search</h1>
@endsection
