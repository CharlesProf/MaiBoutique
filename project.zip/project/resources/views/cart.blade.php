@extends('layout.navbar')

@section('title', 'Cart')

@section('content')
    <h1>Cart</h1>
@endsection
