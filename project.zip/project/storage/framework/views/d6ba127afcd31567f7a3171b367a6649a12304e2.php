<?php $__env->startSection('title', 'Welcome to MaiBoutique'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Welcome to MaiBoutique</h1>
    <h3>
        <a class="w-100 form-control-sm btn-primary" style="text-align: center" href="/signup" type="button">Sign Up Now</a>
    </h3>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\WP Lab Project\WP_lab_project\resources\views/welcome.blade.php ENDPATH**/ ?>