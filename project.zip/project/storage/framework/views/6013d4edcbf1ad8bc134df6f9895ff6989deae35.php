<?php $__env->startSection('title', 'Sign In'); ?>

    <div class="form-container d-flex p-2" style="flex-direction: column; align-items:center">
        <h3 style="text-align: center">Sign In</h3>
        <form action="/signin" method="POST" style="margin-top: 20px; width:50%" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Email</label>
                <input type="text" name="email" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;">Password</label>
                <textarea name="password" rows="3" style="width: 100%"></textarea>
            </div>

            <div class="p-1">
                <p class="w-100"><input class="form-control-sm" type="checkbox" name="remember" id="remember">Remember me</p>
            </div>

            <button type="submit" style="margin-top: 30px">Sign In</button>

            <div>
                <p>Not Registered yet? <a href="/signup">Register here</a></p>
            </div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($err); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <div>
            <?php endif; ?>

        </form>
    </div>


<?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\WP Lab Project\WP_lab_project\resources\views/signIn.blade.php ENDPATH**/ ?>