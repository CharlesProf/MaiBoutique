<?php $__env->startSection('title', 'Profile'); ?>

<?php $__env->startSection('content'); ?>

    <div class="mt-2 text-gray-400 text-sm">

        <h1 class="text-center">My Profile</h1>


        
            <?php if(Auth::user()->role != 'admin'): ?>
                <p class="text-center">Member</p>
            <?php else: ?>
                <p class="text-center"><?php echo e(Auth::user()->role); ?></p>
            <?php endif; ?>


            <p class="text-center">username: <?php echo e(Auth::user()->username); ?></p>
            <p class="text-center"><?php echo e(Auth::user()->email); ?></p>
            
            <p class="text-center">Address: <?php echo e(Auth::user()->address); ?></p>
            <p class="text-center">Phone: <?php echo e(Auth::user()->phone); ?></p>
        

        
        <?php if(Auth::user()->role == 'user'): ?>
            <div class="p-3">
                <a class="w-100 form-control-sm btn-primary" href="/profile/edit-profile" type="button">Edit Profile</a>
            </div>
        <?php endif; ?>

        
        <div class="p-3">
            <a class="w-100 form-control-sm btn-primary" href="/profile/edit-password" type="button">Edit Password</a>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\WP Lab Project\WP_lab_project\resources\views/profile.blade.php ENDPATH**/ ?>