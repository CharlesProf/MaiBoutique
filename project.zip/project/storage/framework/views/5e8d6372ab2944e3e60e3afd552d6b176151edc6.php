<div class="header">
    <h1>Giant Book Supplier</h1>
</div>

<?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\Exam 5\Midexam 5\WebProg uts\Project\resources\views/header.blade.php ENDPATH**/ ?>