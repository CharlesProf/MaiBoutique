<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
<div style="margin-top: 50px">
    <div class="row" style="justify-content:space-evenly">
        <?php if($allBook == 0): ?>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem;margin-top:25px">
                    <div class="card-body">
                        <a href="/categories/<?php echo e($category->id); ?>" style="margin-top: 10px" class="btn btn-secondary"><?php echo e($category->name); ?></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if($allBook == 1): ?>
            <?php $__currentLoopData = $bookCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCtg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($book->id == $bookCtg->book_id): ?>
                        <div class="card" style="width: 18rem;margin-top:25px">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title"><?php echo e($book->image); ?></h5>
                                <h5 class="card-title"><?php echo e($book->title); ?></h5>
                                by:
                                <p class="card-text"><?php echo e($book->author); ?></p>
                                <a href="/home/<?php echo e($book->id); ?>" style="margin-top: 10px" class="mt-auto detail-btn btn-secondary">Details</a>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\Exam 5\Midexam 5\WebProg_UTS_LA02_2440016672\Project\resources\views/categories.blade.php ENDPATH**/ ?>