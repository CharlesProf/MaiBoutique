<?php $__env->startSection('title', 'Edit Password'); ?>

<?php $__env->startSection('content'); ?>

    <div class="form-container d-flex p-2" style="flex-direction: column; align-items:center">
        <h3 style="text-align: center">Edit Profile</h3>
        <form action="/profile/edit-password" method="POST" style="margin-top: 20px; width:50%" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;">Old Password</label>
                <textarea name="old_password" rows="3" style="width: 100%"></textarea>
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;">New Password</label>
                <textarea name="new_password" rows="3" style="width: 100%"></textarea>
            </div>

            <button type="submit" style="margin-top: 30px">Save Update</button>
            <a class="nav-link" href="/profile">Back</a>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($err); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <div>
            <?php endif; ?>

        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\WP Lab Project\WP_lab_project\resources\views/edit-password.blade.php ENDPATH**/ ?>