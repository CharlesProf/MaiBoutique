<?php $__env->startSection('title', 'Add'); ?>

<?php $__env->startSection('content'); ?>
    <div class="form-container">
        <h1>Add Movie</h1>
        <form action="" method="POST" style="margin-top: 20px; width:100%" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Movie Name</label>
                <input type="text" name="movie_name" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;">Movie Description</label>
                <textarea name="movie_description" cols="70" rows="5"></textarea>
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;">Movie Image</label>
                <input type="file" name="movie_image">
            </div>

            <button type="submit" style="margin-top: 30px">Update</button>

            <?php if($errors->any()): ?>
            <?php endif; ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\TemplateSesi3Latihan2\resources\views/add.blade.php ENDPATH**/ ?>