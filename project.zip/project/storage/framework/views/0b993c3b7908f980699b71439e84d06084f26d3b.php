<div class="navbar fixed-bottom">
    <div class="panel-footer footer">
        &#169 Happy Book Store 2022
    </div>
</div>
<?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\Exam 5\Midexam 5\WebProg_UTS_LA02_2440016672\Project\resources\views/footer.blade.php ENDPATH**/ ?>