<?php $__env->startSection('title', 'Publishers'); ?>

<?php $__env->startSection('content'); ?>

    <div style="margin: 50px 100px">
        <div style="margin-top: 50px">
            <div class="row" style="justify-content:space-evenly">

                <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="card" style="width: 18rem; margin-top: 25px">
                        <div class="card-body d-flex flex-column">
                            <?php if($detail == 0 ): ?>
                                <p class="card-text"><?php echo e($publisher->image); ?></p>
                                <p class="card-text"><?php echo e($publisher->name); ?></p>
                                <p class="card-text"><?php echo e($publisher->address); ?></p>
                                <a href="/publishers/<?php echo e($publisher->id); ?>" style="margin-top: 10px" class=" mt-auto detail-btn btn-secondary">Details</a>
                            <?php else: ?>
                                <h4 class="card-title"><?php echo e($publisher->name); ?></h4>
                                <p class="card-text">Address - <?php echo e($publisher->address); ?></p>
                                <p class="card-text">Phone - <?php echo e($publisher->phone); ?></p>
                                <p class="card-text">Email - <?php echo e($publisher->email); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

    <?php if($detail == 1): ?>
        <div class="row" style="justify-content: space-evenly">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem; margin-top: 25px">
                    <div class="card-body d-flex flex-column">
                        <h5 class="card-title"><?php echo e($book->image); ?></h5>
                        <h5 class="card-title"><?php echo e($book->title); ?></h5>
                        by:
                        <p class="card-text"><?php echo e($book->author); ?></p>
                        <a href="/home/<?php echo e($book->id); ?>" style="margin-top: 10px" class="mt-auto detail-btn btn-secondary">Details</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\Exam 5\Midexam 5\WebProg uts\Project\resources\views/publishers.blade.php ENDPATH**/ ?>