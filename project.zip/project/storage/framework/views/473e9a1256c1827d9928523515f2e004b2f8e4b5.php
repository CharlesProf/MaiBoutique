<?php $__env->startSection('title', 'Add'); ?>

<?php $__env->startSection('content'); ?>

    <div class="form-container d-flex p-2" style="flex-direction: column; align-items:center">
        <h3 style="text-align: center">Insert New Publisher</h3>
        <form action="/add" method="POST" style="margin-top: 20px; width:50%" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Publisher ID</label>
                <input type="text" name="publisher_id" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Publisher Name</label>
                <input type="text" name="publisher_name" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;">Publisher Address</label>
                <textarea name="publisher_address" rows="3" style="width: 100%"></textarea>
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Publisher Phone</label>
                <input type="text" name="publisher_phone" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Publisher Email</label>
                <input type="text" name="publisher_email" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;">Publisher Image</label>
                <input type="file" name="publisher_image">
            </div>

            <button type="submit" style="margin-top: 30px">Add Publisher</button>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($err); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <div>
            <?php endif; ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\Exam 5\Midexam 5\WebProg_UTS_LA02_2440016672\Project\resources\views/add.blade.php ENDPATH**/ ?>