<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div style="margin: 50px 100px">
        <h2> <strong class="d-flex justify-content-center">Welcome to WebPlix</strong> </h2>

        <div style="margin-top: 50px">
            <div class="row" style="justify-content:space-evenly">
                
                <div class="card" style="width: 18rem;margin-top:25px">
                    <img class="card-img-top" src="" alt="Movie Image">
                    <div class="card-body">
                        <h5 class="card-title"></h5>
                        <p class="card-text"></p>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <a href="" style="margin-top: 10px" class="btn btn-secondary">Update</a>
                        </div>
                        <div class="row">
                            <a href="" style="margin-top: 10px" class="btn btn-secondary">Delete</a>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\TemplateSesi3Latihan2\resources\views/home.blade.php ENDPATH**/ ?>