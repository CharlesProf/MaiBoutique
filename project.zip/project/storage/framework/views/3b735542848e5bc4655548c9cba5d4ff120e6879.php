<?php $__env->startSection('content'); ?>
    <div style="margin: 50px 100px">
        <h2> <strong class="d-flex justify-content-center" >Welcome to beli film</strong> </h2>

        <div style="margin-top: 50px">
            <div class="row" style="justify-content:space-evenly">
                <?php $__currentLoopData = $movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card" style="width: 18rem;margin-top:25px">
                    <img class="card-img-top" src="<?php echo e(url($m->image)); ?>" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($m->name); ?></h5>
                        <p class="card-text"><?php echo e($m->description); ?></p>
                        <?php if(auth()->guard()->check()): ?>
                            <div class="row">
                                <a href="<?php echo e(url('update/'.$m->id)); ?>" style="margin-top: 10px" class="btn btn-secondary">Update</a>
                            </div>
                            <div class="row">
                                <a href="<?php echo e(url('delete/'.$m->id)); ?>" style="margin-top: 10px" class="btn btn-secondary">Delete</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andre\OneDrive\Documents\Aslab\Ngajar\Laravel\Meet 2\sesi2\resources\views/home.blade.php ENDPATH**/ ?>