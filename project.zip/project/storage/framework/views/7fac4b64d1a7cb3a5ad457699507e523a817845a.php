<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div style="margin: 50px 100px">
        <div style="margin-top: 50px">
            <div class="row" style="justify-content:space-evenly">

                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="width: 18rem; margin-top: 25px">
                        <div class="card-body d-flex flex-column">
                            <?php if($detail == 1 ): ?>
                                <h5 class="card-title"><?php echo e($book->image); ?></h5>
                                <p class="card-title">Title: <?php echo e($book->title); ?></p>
                                <p class="card-text">Author: <?php echo e($book->author); ?></p>
                                <p class="card-text">Publisher: <?php echo e($publisherName); ?></p>
                                <p class="card-text">Year: <?php echo e($book->year); ?></p>
                                Synopsis:
                                <p class="card-text"><?php echo e($book->synopsis); ?></p>
                            <?php else: ?>
                                <h5 class="card-title"><?php echo e($book->image); ?></h5>
                                <h5 class="card-title"><?php echo e($book->title); ?></h5>
                                by:
                                <p class="card-text"><?php echo e($book->author); ?></p>
                                <a href="/home/<?php echo e($book->id); ?>" style="margin-top: 10px" class=" mt-auto detail-btn btn-secondary ">Details</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\Exam 5\Midexam 5\WebProg uts\Project\resources\views/home.blade.php ENDPATH**/ ?>