<?php $__env->startSection('title', 'Search'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Search</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\WP Lab Project\WP_lab_project\resources\views/search.blade.php ENDPATH**/ ?>