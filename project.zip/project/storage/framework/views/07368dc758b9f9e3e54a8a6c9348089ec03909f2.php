<?php $__env->startSection('title', 'Contact'); ?>

<?php $__env->startSection('content'); ?>
<div style="margin-top: 10px">
    <div class="row">

        <div class ="content-title" style="margin-left: 5px; padding: 10px; color: white; background-color:gray;">
            <h3>Contact</h3>
        </div>
            <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publisher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card-body">
                    <h4>Store address:</h4>
                    <p class="card-text"><?php echo e($publisher->address); ?></p>
                    <h4>Contact:</h4>
                    <p class="card-title">Email: <?php echo e($publisher->email); ?></p>
                    <p class="card-title">Phone number: <?php echo e($publisher->phone); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\Exam 5\Midexam 5\WebProg uts\Project\resources\views/contact.blade.php ENDPATH**/ ?>