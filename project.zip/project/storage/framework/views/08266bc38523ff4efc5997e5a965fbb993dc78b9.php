<?php $__env->startSection('title','Update'); ?>

<?php $__env->startSection('content'); ?>
    <div class="form-container">
        <h1>Update Movie</h1>
        <form action="<?php echo e(url('update/'.$movie->id)); ?>" method="POST" style="margin-top: 20px; width:100%" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;" >Movie Name</label>
                <input type="text" value="<?php echo e($movie->name); ?>" name="movie_name" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;" >Movie Description</label>
                <textarea name="movie_description"  cols="75" rows="5"><?php echo e($movie->description); ?></textarea>
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;" >Movie Image</label>
                <input type="file" name="movie_image" >
            </div>

            <button type="submit" style="margin-top: 30px">Update</button>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projects\Laravel\TemplateSesi3\resources\views/update.blade.php ENDPATH**/ ?>