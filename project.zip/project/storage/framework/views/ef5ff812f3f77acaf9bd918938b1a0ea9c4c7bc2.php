<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div style="margin: 50px 100px">
        <div style="margin-top: 50px">
            <div class="row" style="justify-content:space-evenly">

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card" style="width: 18rem; margin-top: 25px">
                        <div class="card-body d-flex flex-column">
                            <?php if($detail == 1 ): ?>
                                
                            <?php else: ?>
                                <h5 class="card-title"><?php echo e($product->image); ?></h5>
                                <h5 class="card-title"><?php echo e($product->title); ?></h5>

                                <a href="/home/<?php echo e($product->id); ?>" style="margin-top: 10px" class=" mt-auto detail-btn btn-secondary ">More Detail</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                  <li class="page-item"><a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>">Previous</a></li>
                  


                  
                    <?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
                     <li class="page-item"><a class="page-link" href="<?php echo e($products->url($i)); ?>"><?php echo e($i); ?></a></li>
                    <?php endfor; ?>
                  

                  <li class="page-item"><a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>">Next</a></li>
                </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\WP Lab Project\WP_lab_project\resources\views/home.blade.php ENDPATH**/ ?>