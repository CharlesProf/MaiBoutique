<?php $__env->startSection('title', 'Edit'); ?>

<?php $__env->startSection('content'); ?>

    <div class="form-container d-flex p-2" style="flex-direction: column; align-items:center">
        <h3 style="text-align: center">Edit Profile</h3>
        <form action="/edit" method="POST" style="margin-top: 20px; width:50%" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Username</label>
                <input type="text" name="username" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Email</label>
                <input type="text" name="email" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;">Password</label>
                <textarea name="password" rows="3" style="width: 100%"></textarea>
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Phone Number</label>
                <input type="text" name="phone" style="width: 100%">
            </div>

            <div class="update-menu">
                <label for="" style="display:block; margin-bottom:5px;margin-top:20px;">Address</label>
                <input type="text" name="address" style="width: 100%">
            </div>

            <button type="submit" style="margin-top: 30px">Submit</button>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($err); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <div>
            <?php endif; ?>

        </form>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Javier\Desktop\Javier Files\College\Semesters\Semester 5\WP Lab Project\WP_lab_project\resources\views/edit.blade.php ENDPATH**/ ?>